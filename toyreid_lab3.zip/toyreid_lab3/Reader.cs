// Toy Reid
// CS365 - Lab 3
// 02/28/18

using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;

// Used to read binary file, make the generic list, sort, and write text file
class Reader {
    protected BinaryReader binRead;
    protected StreamWriter strWrite;
    protected string inFile;
    protected string outFile;
    protected List<byte[]> rawNums = new List<byte[]>();
    protected List<ICompValue> nums = new List<ICompValue>();

    public static void Main(string[] args) {
        Reader r = new Reader(args[0], args[1]);

        r.Read();
        r.MakeList();
        r.DoSort();
        r.WriteList();
    }

    public Reader(string i, string o) {
        inFile = i;
        outFile = o;
    }

    // Writes the list to the specified output file
    public void WriteList() {
        using(strWrite = new StreamWriter(outFile)) {
            foreach(ICompValue comp in nums) {
                strWrite.WriteLine(comp.Val);
            }
        }
    }

    // Calls IComparable's sort on the list
    public void DoSort() {
        nums.Sort();
    }

    // Generates the list of ICompValues
    public void MakeList() {
        foreach(byte[] it in rawNums) {
            if(it.Length == 5) {
                if(it[0] == 0) { // BCD
                    BCD b = new BCD();
                    b.Raw = BitConverter.ToUInt32(it, 1); // Set Raw
                    Console.WriteLine(String.Format("Adding {0}", b.Val));
                    nums.Add(b);
                }
                else if(it[0] == 1) { // DPD
                    DPD d = new DPD();
                    d.Raw = BitConverter.ToUInt32(it, 1); // Set Raw
                    Console.WriteLine(String.Format("Adding {0}", d.Val));
                    nums.Add(d);
                }
            }
        }
    }

    // Switches the endianness of a 5-byte array (with index 0 being the mod byte)
    public byte[] SwitchEndianness(byte[] change) {
        byte temp;

        temp = change[1];
        change[1] = change[4];
        change[4] = temp;

        temp = change[2];
        change[2] = change[3];
        change[3] = temp;

        return change;
    }

    // Read file into byte array
    public void Read() {
        using(binRead = new BinaryReader(File.OpenRead(inFile))) {
            bool stay = true;

            while(stay) {
                byte[] comp = new byte[5];

                for(int i = 0; i < 5; i++) {
                    try {
                        comp[i] = binRead.ReadByte();
                    }
                    catch(EndOfStreamException) { // End of file, exit loop
                        stay = false;
                        break;
                    }
                }
                if(stay) { // If didn't reach EOF, add to rawNums array
                    comp = SwitchEndianness(comp);
                    rawNums.Add(comp);
                }
            }
        }
    }
}