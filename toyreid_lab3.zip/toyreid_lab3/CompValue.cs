// Toy Reid
// CS365 - Lab 3
// 02/28/18

abstract class CompValue : ICompValue {
    protected uint rawVal;

    public uint Raw {
        get {
            return rawVal;
        }
        set {
            rawVal = value;
        }
    }
    public virtual uint Val { get; }

    public int CompareTo(object o) {
        ICompValue obj = (ICompValue)o;
        /// return -1 if this.Val < object.Val (object typecasted into ICompValue)
        /// return 0 if this.Val == object.Val (object typecasted into ICompValue)
        /// return 1 if this.Val > object.Val
        if(this.Val < obj.Val) return -1;
        else if(this.Val == obj.Val) return 0;
        else return 1;
    }
}