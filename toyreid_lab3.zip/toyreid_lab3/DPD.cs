// Toy Reid
// CS365 - Lab 3
// 02/28/18

class DPD : CompValue {
    public override uint Val {
        get {
            const uint mask = 0x3ff; // Mask to look at 10 bits at a time
            string temp = "";
            uint shift = 20;
            uint chunk = (rawVal >> shift) & mask; // chunk = first 10 bits in DPD
            uint tmpChunk;

            // Analyze one chunk of 10 bits at a time
            // Each if statement corresponds to one row of the DPD encoding table
            // Bit shifting and masking is used to move the bits into their unpacked format
            while(shift >= 0) {
                // chunk[6] == 0
                if(((chunk >> 3) & 1) == 0) {
                    // ROW 1
                    tmpChunk = (chunk >> 7) & 7;
                    temp += tmpChunk.ToString();
                    tmpChunk = (chunk >> 4) & 7;
                    temp += tmpChunk.ToString();
                    tmpChunk = chunk & 7;
                    temp += tmpChunk.ToString();
                }
                // chunk[6] == 1
                else {
                    // chunk[7] == 0
                    if(((chunk >> 2) & 1) == 0) {
                        tmpChunk = (chunk >> 7) & 7;
                        temp += tmpChunk.ToString();
                        // chunk[8] == 0
                        if(((chunk >> 1) & 1) == 0) {
                            // ROW 2
                            tmpChunk = (chunk >> 4) & 7;
                            temp += tmpChunk.ToString();
                            tmpChunk = 8; // 1000
                            tmpChunk |= chunk & 1;
                            temp += tmpChunk.ToString();
                        }
                        // chunk[8] == 1
                        else {
                            // ROW 3
                            tmpChunk = 8;
                            tmpChunk |= (chunk >> 4) & 1;
                            temp += tmpChunk.ToString();
                            tmpChunk = 0;
                            tmpChunk |= chunk & 1;
                            tmpChunk |= (chunk >> 4) & 6; // 110
                            temp += tmpChunk.ToString();
                        }
                    }
                    // chunk[7] == 1
                    else {
                        // chunk[8] == 0
                        if(((chunk >> 1) & 1) == 0) {
                            // ROW 4
                            tmpChunk = 8;
                            tmpChunk |= (chunk >> 7) & 1;
                            temp += tmpChunk.ToString();
                            tmpChunk = (chunk >> 4) & 7;
                            temp += tmpChunk.ToString();
                            tmpChunk = 0;
                            tmpChunk |= chunk & 1;
                            tmpChunk |= (chunk >> 7) & 6;
                            temp += tmpChunk.ToString();
                        }
                        // chunk[8] == 1
                        else {
                            // chunk[3] == 0
                            if(((chunk >> 6) & 1) == 0) {
                                // chunk[4] == 0
                                tmpChunk = 8;
                                tmpChunk |= (chunk >> 7) & 1;
                                temp += tmpChunk.ToString();
                                if(((chunk >> 5) & 1) == 0) {
                                    // ROW 5
                                    tmpChunk = 8;
                                    tmpChunk |= (chunk >> 4) & 1;
                                    temp += tmpChunk.ToString();
                                    tmpChunk = 0;
                                    tmpChunk |= chunk & 1;
                                    tmpChunk |= (chunk >> 7) & 6;
                                    temp += tmpChunk.ToString();
                                }
                                // chunk[4] == 1
                                else {
                                    // ROW 6
                                    tmpChunk = 0;
                                    tmpChunk |= (chunk >> 7) & 6;
                                    tmpChunk |= (chunk >> 4) & 1;
                                    temp += tmpChunk.ToString();
                                    tmpChunk = 8;
                                    tmpChunk |= chunk & 1;
                                    temp += tmpChunk.ToString();
                                }
                            }
                            // chunk[3] == 1
                            else {
                                // chunk[4] == 0
                                if(((chunk >> 5) & 1) == 0) {
                                    // ROW 7
                                    tmpChunk = (chunk >> 7) & 7;
                                    temp += tmpChunk.ToString();
                                    tmpChunk = 8;
                                    tmpChunk |= (chunk >> 4) & 1;
                                    temp += tmpChunk.ToString();
                                    tmpChunk = 8;
                                    tmpChunk |= chunk & 1;
                                    temp += tmpChunk.ToString();
                                }
                                // chunk[4] == 1
                                else {
                                    // ROW 8
                                    tmpChunk = 8;
                                    tmpChunk |= (chunk >> 7) & 1;
                                    temp += tmpChunk.ToString();
                                    tmpChunk = 8;
                                    tmpChunk |= (chunk >> 4) & 1;
                                    temp += tmpChunk.ToString();
                                    tmpChunk = 8;
                                    tmpChunk |= chunk & 1;
                                    temp += tmpChunk.ToString();
                                }
                            }
                        }
                    }
                }

                // Move to next 10 bits in DPD
                shift -= 10;
                chunk = (rawVal >> shift) & mask;
            }

            return uint.Parse(temp);
        }
    }
}