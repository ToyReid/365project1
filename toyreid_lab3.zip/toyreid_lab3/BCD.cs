// Toy Reid
// CS365 - Lab 3
// 02/28/18

class BCD : CompValue {
    public override uint Val {
        get {
            int i;
            uint a, b;
            uint mask = 0xf;
            string temp;

            a = rawVal >> 28;
            temp = a.ToString(); // First value is first 4 bytes
                                 // No mask b/c everything else shifted out

            for(i = 24; i >= 0; i -= 4) {
                // Shift and mask each increment of 4 bits, then add it to the string
                b = (rawVal >> i) & mask;
                temp += b.ToString();
            }

            return uint.Parse(temp);
        }
    }
}